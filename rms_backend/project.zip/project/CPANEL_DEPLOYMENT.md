# cPanel Deployment Guide for RMS Backend

## Prerequisites
1. cPanel hosting with Python support
2. MySQL database access
3. File manager access

## Deployment Steps

### 1. Upload Files
- Upload the entire `project` folder to your cPanel's `public_html` directory
- Ensure the folder structure is: `public_html/project/`

### 2. Database Setup
- Create a MySQL database in cPanel
- Create a database user with full privileges
- Note down the database credentials

### 3. Environment Variables
Create a `.env` file in the project root with:
```
DEBUG=False
SECRET_KEY=your-secret-key-here
DB_NAME=your_database_name
DB_USER=your_database_user
DB_PASSWORD=your_database_password
DB_HOST=localhost
DB_PORT=3306
```

### 4. Python Virtual Environment
In cPanel Terminal:
```bash
cd public_html/project
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### 5. Django Setup
```bash
python manage.py collectstatic --noinput
python manage.py migrate
python manage.py createsuperuser
```

### 6. File Permissions
Set proper permissions:
- `passenger_wsgi.py` should be executable
- `staticfiles/` and `media/` folders should be writable

### 7. cPanel Configuration
- In cPanel, go to "Python App" or "Passenger"
- Set the application root to `/public_html/project`
- Set the startup file to `passenger_wsgi.py`
- Set Python version to 3.8+ (recommended 3.9 or 3.10)

### 8. Static Files
- The `.htaccess` file will handle static file serving
- Ensure static files are collected in the `staticfiles` directory

## Troubleshooting

### Common Issues:
1. **Import Errors**: Check Python path in `passenger_wsgi.py`
2. **Database Connection**: Verify database credentials in `.env`
3. **Static Files**: Ensure `collectstatic` was run and `.htaccess` is in place
4. **Permission Errors**: Check file permissions for Django to write logs

### Logs Location:
- Django logs: Check cPanel error logs
- Application logs: Usually in `/public_html/project/logs/`

## Security Notes:
- Keep `DEBUG=False` in production
- Use strong `SECRET_KEY`
- Regularly update dependencies
- Monitor error logs for security issues
