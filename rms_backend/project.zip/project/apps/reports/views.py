from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from django.db.models import Sum, Count, Avg, F, Q, DecimalField, Max, OuterRef, Subquery, Case, When, Value, CharField, DateField
from django.db.models.functions import Coalesce, Cast, TruncDate
from django.utils import timezone
from datetime import timedelta, datetime, time
from decimal import Decimal
from .models import Report, ReportMetric, ReportDataPoint, SavedReport
from .serializers import (
    ReportSerializer, SavedReportSerializer,
    SalesReportSerializer, ExpenseReportSerializer,
    InventoryReportSerializer, CustomerReportSerializer,
    CategoryReportSerializer, ProfitLossReportSerializer,
    ProductPerformanceReportSerializer
)
from apps.sales.models import Sale, SaleItem
from apps.expenses.models import Expense, ExpenseCategory
from apps.inventory.models import Product, Category, StockMovement
from apps.customer.models import Customer
from apps.preorder.models import Preorder, PreorderProduct
from apps.online_preorder.models import OnlinePreorder
import logging

logger = logging.getLogger(__name__)

class ReportViewSet(viewsets.ModelViewSet):
    queryset = Report.objects.all()
    serializer_class = ReportSerializer

    def _get_date_range(self, request):
        date_from_str = request.query_params.get('date_from')
        date_to_str = request.query_params.get('date_to')

        if not date_from_str or not date_to_str:
            return None, None, Response({"error": "date_from and date_to parameters are required."}, status=status.HTTP_400_BAD_REQUEST)
        
        try:
            date_from = timezone.make_aware(datetime.strptime(date_from_str, '%Y-%m-%d'))
            date_to = timezone.make_aware(datetime.combine(datetime.strptime(date_to_str, '%Y-%m-%d'), time.max))
        except ValueError:
            return None, None, Response({"error": "Invalid date format. Use YYYY-MM-DD."}, status=status.HTTP_400_BAD_REQUEST)

        return date_from, date_to, None

    @action(detail=False, methods=['get'])
    def overview(self, request):
        date_from, date_to, error = self._get_date_range(request)
        if error:
            return error

        # Sales data
        sales = Sale.objects.filter(date__range=[date_from, date_to], status='completed')
        total_sales = sales.aggregate(total=Sum('total'))['total'] or Decimal('0.00')
        total_orders = sales.count()
        
        # Expense data
        expenses = Expense.objects.filter(date__range=[date_from, date_to], status='APPROVED')
        total_expenses = expenses.aggregate(total=Sum('amount'))['total'] or Decimal('0.00')

        # Profit & Loss data
        total_profit = sales.aggregate(total=Sum('total_profit'))['total'] or Decimal('0.00')
        net_profit = total_profit # Simplified for overview
        profit_margin = (net_profit / total_sales * 100) if total_sales > 0 else Decimal('0.00')

        # Preorder analysis
        preorders = Preorder.objects.filter(created_at__range=[date_from, date_to])
        preorder_status_breakdown = {}
        for status_choice in Preorder.STATUS_CHOICES:
            preorder_status_breakdown[status_choice[0]] = preorders.filter(status=status_choice[0]).count()
        # Only count revenue and profit for COMPLETED preorders
        completed_preorders = preorders.filter(status='COMPLETED')
        preorder_total_orders = completed_preorders.count()
        preorder_total_revenue = completed_preorders.aggregate(total=Sum('total_amount'))['total'] or Decimal('0.00')
        preorder_profit = completed_preorders.aggregate(total=Sum('profit'))['total'] or Decimal('0.00')

        # Data for charts
        sales_by_date = sales.values('date__date').annotate(date=F('date__date'), total=Sum('total')).order_by('date')
        expenses_by_date = expenses.values('date').annotate(total=Sum('amount')).order_by('date')

        data = {
            "total_sales": total_sales,
            "total_orders": total_orders,
            "total_expenses": total_expenses,
            "net_profit": net_profit,
            "profit_margin": profit_margin,
            "sales_by_date": list(sales_by_date),
            "expenses_by_date": list(expenses_by_date),
            # Preorder analytics
            "preorder_total_orders": preorder_total_orders,
            "preorder_total_revenue": preorder_total_revenue,
            "preorder_profit": preorder_profit,
            "preorder_status_breakdown": preorder_status_breakdown,
        }
        
        return Response(data)

    @action(detail=False, methods=['get'])
    def sales(self, request):
        date_from, date_to, error = self._get_date_range(request)
        if error:
            return error
        
        sales = Sale.objects.filter(
            date__range=[date_from, date_to],
            status='completed'
        )

        total_sales = sales.aggregate(total=Sum('total'))['total'] or Decimal('0.00')
        total_orders = sales.count()
        total_items_sold = sales.aggregate(total_items=Sum('items__quantity'))['total_items'] or 0

        average_order_value = total_sales / total_orders if total_orders > 0 else Decimal('0.00')
        average_item_price = total_sales / total_items_sold if total_items_sold > 0 else Decimal('0.00')

        # Sales by date
        sales_by_date = sales.values('date__date').annotate(
            date=F('date__date'),
            total=Sum('total'),
            items_count=Sum('items__quantity')
        ).order_by('date__date')

        # Sales by category
        sales_by_category = SaleItem.objects.filter(
            sale__in=sales
        ).values(
            'product__category__name'
        ).annotate(
            category_name=F('product__category__name'),
            total=Sum('total'),
            items_count=Count('id'),
            quantity_sold=Sum('quantity')
        ).order_by('-total')

        # Top products
        top_products = SaleItem.objects.filter(
            sale__in=sales
        ).values(
            'product__name',
            'product__category__name'
        ).annotate(
            product_name=F('product__name'),
            category_name=F('product__category__name'),
            total_sales=Sum('total'),
            quantity_sold=Sum('quantity'),
            average_price=Avg('unit_price'),
            profit=Sum('profit')
        ).order_by('-total_sales')[:10]

        # Payment methods
        payment_methods = sales.values(
            'payment_method'
        ).annotate(
            total=Sum('total'),
            orders_count=Count('id'),
            items_count=Sum('items__quantity')
        ).order_by('-total')

        data = {
            'total_sales': total_sales,
            'total_orders': total_orders,
            'total_items_sold': total_items_sold,
            'average_order_value': average_order_value,
            'average_item_price': average_item_price,
            'sales_by_date': list(sales_by_date),
            'sales_by_category': list(sales_by_category),
            'top_products': list(top_products),
            'payment_methods': list(payment_methods)
        }

        serializer = SalesReportSerializer(data)
        return Response(serializer.data)

    @action(detail=False, methods=['get'])
    def expenses(self, request):
        date_from, date_to, error = self._get_date_range(request)
        if error:
            return error

        expenses = Expense.objects.filter(
            date__range=[date_from, date_to],
            status='APPROVED'
        )

        total_expenses = expenses.aggregate(total=Sum('amount'))['total'] or Decimal('0.00')

        # Expenses by category
        expenses_by_category = expenses.values(
            'category__name'
        ).annotate(
            category_name=F('category__name'),
            total=Sum('amount'),
            count=Count('id')
        ).order_by('-total')

        # Expenses by date
        expenses_by_date = expenses.annotate(
            expense_date=Cast('date', DateField())
        ).values('expense_date').annotate(
            amount=Sum('amount'),
            count=Count('id')
        ).order_by('expense_date')

        # Simplified expenses over time for charting
        expenses_over_time = [
            {'date': e['expense_date'], 'amount': e['amount']} for e in expenses_by_date
        ]

        data = {
            'total_expenses': total_expenses,
            'expenses_by_category': list(expenses_by_category),
            'expenses_by_date': list(expenses_by_date),
            'expenses_over_time': expenses_over_time,
        }

        serializer = ExpenseReportSerializer(data)
        return Response(serializer.data)

    @action(detail=False, methods=['get'])
    def inventory(self, request):
        products = Product.objects.all()
        total_products = products.count()
        total_stock_value = products.aggregate(
            total=Sum(F('stock_quantity') * F('selling_price'))
        )['total'] or Decimal('0.00')

        # Low stock items
        low_stock_items = products.filter(
            stock_quantity__lte=F('minimum_stock')
        ).values(
            'name', 'stock_quantity', 'minimum_stock', 'selling_price'
        ).annotate(
            stock=F('stock_quantity'),
            reorder_level=F('minimum_stock'),
            price=F('selling_price')
        ).order_by('stock_quantity')

        # Stock by category
        stock_by_category = products.values(
            'category__name'
        ).annotate(
            category_name=F('category__name'),
            total_products=Count('id'),
            total_stock=Sum('stock_quantity'),
            total_value=Sum(F('stock_quantity') * F('selling_price'))
        ).order_by('-total_value')

        # Stock movements
        stock_movements = StockMovement.objects.values(
            'created_at__date', 'movement_type'
        ).annotate(
            date=F('created_at__date'),
            total_quantity=Sum('quantity'),
            total_value=Sum(F('quantity') * F('product__cost_price'))
        ).order_by('-created_at__date')[:30]

        data = {
            'total_products': total_products,
            'total_stock_value': total_stock_value,
            'low_stock_items': list(low_stock_items),
            'stock_by_category': list(stock_by_category),
            'stock_movements': list(stock_movements)
        }

        serializer = InventoryReportSerializer(data)
        return Response(serializer.data)

    @action(detail=False, methods=['get'])
    def customers(self, request):
        date_from, date_to, error = self._get_date_range(request)
        if error:
            return error

        customers = Customer.objects.all()
        total_customers = customers.count()
        new_customers = customers.filter(
            created_at__range=[date_from, date_to]
        ).count()

        # Calculate total sales and average customer value
        sales = Sale.objects.filter(
            date__range=[date_from, date_to],
            status='completed'
        )
        total_sales = sales.aggregate(total=Sum('total'))['total'] or Decimal('0.00')
        active_customers_count = sales.values('customer').distinct().count()
        average_customer_value = total_sales / active_customers_count if active_customers_count > 0 else Decimal('0.00')

        # Top customers
        top_customers = sales.values('customer_id').annotate(
            first_name=F('customer__first_name'),
            last_name=F('customer__last_name'),
            phone=F('customer__phone'),
            total_sales=Sum('total'),
            items_purchased=Sum('items__quantity'),
            unique_products=Count('items__product', distinct=True),
            last_purchase_date=Cast(Max('date'), DateField())
        ).order_by('-total_sales')[:10]

        # Customer acquisition
        customer_acquisition = Customer.objects.filter(
            created_at__range=[date_from, date_to]
        ).annotate(date=TruncDate('created_at')).values('date').annotate(
            new_customers=Count('id')
        ).order_by('date')

        data = {
            'total_customers': total_customers,
            'new_customers': new_customers,
            'total_sales': total_sales,
            'average_customer_value': average_customer_value,
            'top_customers': list(top_customers),
            'customer_acquisition': list(customer_acquisition)
        }

        serializer = CustomerReportSerializer(data)
        return Response(serializer.data)

    @action(detail=False, methods=['get'])
    def categories(self, request):
        date_from, date_to, error = self._get_date_range(request)
        if error:
            return error

        categories = Category.objects.all()
        total_categories = categories.count()
        total_products = Product.objects.count()

        # Sales by category
        sales_by_category = SaleItem.objects.filter(
            sale__date__range=[date_from, date_to]
        ).values('product__category__name').annotate(
            category_name=F('product__category__name'),
            total_sales=Sum('total'),
            items_sold=Sum('quantity'),
            unique_products=Count('product', distinct=True)
        ).order_by('-total_sales')

        # Stock by category
        stock_by_category = Product.objects.values(
            'category__name'
        ).annotate(
            category_name=F('category__name'),
            total_products=Count('id'),
            total_stock=Sum('stock_quantity'),
            total_value=Sum(F('stock_quantity') * F('selling_price'))
        ).order_by('-total_value')

        # Top categories by sales
        top_categories = Category.objects.annotate(
            total_sales=Coalesce(Sum(
                'products__saleitem__total',
                filter=Q(products__saleitem__sale__date__range=[date_from, date_to])
            ), Decimal('0.00')),
            items_sold=Coalesce(Sum(
                'products__saleitem__quantity',
                filter=Q(products__saleitem__sale__date__range=[date_from, date_to])
            ), 0),
            product_count=Count('products', distinct=True)
        ).annotate(
            average_price=Case(
                When(items_sold__gt=0, then=F('total_sales') / F('items_sold')),
                default=Decimal('0.0'),
                output_field=DecimalField()
            )
        ).order_by('-total_sales')[:10]

        data = {
            'total_categories': total_categories,
            'total_products': total_products,
            'sales_by_category': list(sales_by_category),
            'stock_by_category': list(stock_by_category),
            'top_categories': top_categories.values(
                'name', 'total_sales', 'items_sold', 'product_count', 'average_price'
            )
        }
        serializer = CategoryReportSerializer(data)
        return Response(serializer.data)

    @action(detail=False, methods=['get'], url_path='profit-loss')
    def profit_loss(self, request):
        date_from, date_to, error = self._get_date_range(request)
        if error:
            return error

        # Sales and profit
        sales = Sale.objects.filter(
            date__range=[date_from, date_to],
            status='completed'
        )
        total_revenue = sales.aggregate(total=Sum('total'))['total'] or Decimal('0.00')
        total_profit = sales.aggregate(total=Sum('total_profit'))['total'] or Decimal('0.00')

        # Expenses
        expenses = Expense.objects.filter(
            date__range=[date_from, date_to],
            status='APPROVED'
        )
        total_expenses = expenses.aggregate(total=Sum('amount'))['total'] or Decimal('0.00')

        net_profit = total_revenue - total_expenses
        profit_margin = (net_profit / total_revenue * 100) if total_revenue > 0 else Decimal('0.00')

        # Preorder analysis
        preorders = Preorder.objects.filter(created_at__range=[date_from, date_to])
        preorder_status_breakdown = {}
        for status_choice in Preorder.STATUS_CHOICES:
            preorder_status_breakdown[status_choice[0]] = preorders.filter(status=status_choice[0]).count()
        # Only count revenue and profit for COMPLETED preorders
        completed_preorders = preorders.filter(status='COMPLETED')
        preorder_total_orders = completed_preorders.count()
        preorder_total_revenue = completed_preorders.aggregate(total=Sum('total_amount'))['total'] or Decimal('0.00')
        preorder_profit = completed_preorders.aggregate(total=Sum('profit'))['total'] or Decimal('0.00')

        # Revenue by date
        revenue_by_date = sales.annotate(
            sale_date=Cast('date', DateField())
        ).values('sale_date').annotate(
            revenue=Sum('total'),
            items_sold=Sum('items__quantity')
        ).order_by('sale_date')

        # Expenses by date
        expenses_by_date = expenses.annotate(
            expense_date=Cast('date', DateField())
        ).values('expense_date').annotate(
            amount=Sum('amount'),
            count=Count('id')
        ).order_by('expense_date')

        # Simplified expenses over time for charting
        expenses_over_time = [
            {'date': e['expense_date'], 'amount': e['amount']} for e in expenses_by_date
        ]

        # --- Combine revenue and expenses by date for charting ---
        from collections import defaultdict
        import datetime
        # Normalize date keys to string for correct matching
        revenue_map = {str(r['sale_date']): r['revenue'] for r in revenue_by_date}
        expense_map = {str(e['expense_date']): e['amount'] for e in expenses_by_date}
        all_dates = set(revenue_map.keys()) | set(expense_map.keys())
        revenue_vs_expense_by_date = []
        for d in sorted(all_dates):
            revenue_vs_expense_by_date.append({
                'date': d,
                'revenue': revenue_map.get(d, 0),
                'expense': expense_map.get(d, 0)
            })
        # ---

        # Profit by category
        profit_by_category = SaleItem.objects.filter(
            sale__date__range=[date_from, date_to],
            sale__status='completed'
        ).values('product__category__name').annotate(
            category_name=F('product__category__name'),
            revenue=Sum('total'),
            cost=Sum('product__cost_price'),
            profit=Sum('profit'),
            items_sold=Sum('quantity')
        ).order_by('-profit')

        data = {
            'total_revenue': total_revenue,
            'total_expenses': total_expenses,
            'net_profit': net_profit,
            'profit_margin': profit_margin,
            'revenue_by_date': list(revenue_by_date),
            'expenses_by_date': list(expenses_by_date),
            'expenses_over_time': expenses_over_time,
            'revenue_vs_expense_by_date': revenue_vs_expense_by_date,
            'profit_by_category': list(profit_by_category),
            # Preorder analytics
            'preorder_total_orders': preorder_total_orders,
            'preorder_total_revenue': preorder_total_revenue,
            'preorder_profit': preorder_profit,
            'preorder_status_breakdown': preorder_status_breakdown,
        }
        serializer = ProfitLossReportSerializer(data)
        return Response(serializer.data)

    @action(detail=False, methods=['get'], url_path='product-performance')
    def product_performance(self, request):
        date_from, date_to, error = self._get_date_range(request)
        if error:
            return error

        sales_items = SaleItem.objects.filter(sale__date__range=[date_from, date_to], sale__status='completed')
        
        products = Product.objects.all()
        total_products = products.count()
        total_sales = sales_items.aggregate(total=Sum('total'))['total'] or Decimal('0.00')
        total_profit = sales_items.aggregate(total=Sum('profit'))['total'] or Decimal('0.00')
        average_profit_margin = (total_profit / total_sales * 100) if total_sales > 0 else Decimal('0.00')
        
        # Calculate average profit and average selling price with discount
        total_quantity_sold = sales_items.aggregate(total=Sum('quantity'))['total'] or 0
        total_discounts = sales_items.aggregate(total=Sum('discount'))['total'] or Decimal('0.00')
        
        average_profit = (total_profit / total_quantity_sold) if total_quantity_sold > 0 else Decimal('0.00')
        average_selling_price_with_discount = (total_sales / total_quantity_sold) if total_quantity_sold > 0 else Decimal('0.00')

        # Top performing products
        top_performing_products = sales_items.values(
            'product__id', 'product__name', 'product__category__name'
        ).annotate(
            product_id=F('product__id'),
            product_name=F('product__name'),
            category_name=F('product__category__name'),
            total_sales=Sum('total'),
            quantity_sold=Sum('quantity'),
            total_profit=Sum('profit'),
            total_discount=Sum('discount'),
            average_price=Avg('unit_price')
        ).annotate(
            profit_margin=Case(
                When(total_sales__gt=0, then=(F('total_profit') / F('total_sales')) * 100),
                default=Decimal('0.0'),
                output_field=DecimalField()
            ),
            average_profit=Case(
                When(quantity_sold__gt=0, then=F('total_profit') / F('quantity_sold')),
                default=Decimal('0.0'),
                output_field=DecimalField()
            ),
            average_selling_price_with_discount=Case(
                When(quantity_sold__gt=0, then=F('total_sales') / F('quantity_sold')),
                default=Decimal('0.0'),
                output_field=DecimalField()
            )
        ).order_by('-total_profit')[:10]

        # Low performing products
        low_performing_products = sales_items.values(
            'product__id', 'product__name', 'product__category__name'
        ).annotate(
            product_id=F('product__id'),
            product_name=F('product__name'),
            category_name=F('product__category__name'),
            total_sales=Sum('total'),
            quantity_sold=Sum('quantity'),
            total_profit=Sum('profit'),
            total_discount=Sum('discount'),
            average_price=Avg('unit_price')
        ).annotate(
            profit_margin=Case(
                When(total_sales__gt=0, then=(F('total_profit') / F('total_sales')) * 100),
                default=Decimal('0.0'),
                output_field=DecimalField()
            ),
            average_profit=Case(
                When(quantity_sold__gt=0, then=F('total_profit') / F('quantity_sold')),
                default=Decimal('0.0'),
                output_field=DecimalField()
            ),
            average_selling_price_with_discount=Case(
                When(quantity_sold__gt=0, then=F('total_sales') / F('quantity_sold')),
                default=Decimal('0.0'),
                output_field=DecimalField()
            )
        ).order_by('total_profit')[:10]

        # Sales by product
        sales_by_product = sales_items.values('product__id', 'product__name').annotate(
            product_id=F('product__id'),
            product_name=F('product__name'),
            total_sales=Sum('total'),
            quantity_sold=Sum('quantity'),
            total_discount=Sum('discount'),
            average_price=Avg('unit_price')
        ).annotate(
            average_selling_price_with_discount=Case(
                When(quantity_sold__gt=0, then=F('total_sales') / F('quantity_sold')),
                default=Decimal('0.0'),
                output_field=DecimalField()
            )
        ).order_by('-total_sales')

        # Profit by product
        profit_by_product = sales_items.values('product__id', 'product__name').annotate(
            product_id=F('product__id'),
            product_name=F('product__name'),
            total_sales=Sum('total'),
            total_profit=Sum('profit'),
            quantity_sold=Sum('quantity')
        ).annotate(
            profit_margin=Case(
                When(total_sales__gt=0, then=(F('total_profit') / F('total_sales')) * 100),
                default=Decimal('0.0'),
                output_field=DecimalField()
            ),
            average_profit=Case(
                When(quantity_sold__gt=0, then=F('total_profit') / F('quantity_sold')),
                default=Decimal('0.0'),
                output_field=DecimalField()
            )
        ).order_by('-total_profit')
        
        data = {
            'total_products': total_products,
            'total_sales': total_sales,
            'total_profit': total_profit,
            'average_profit_margin': average_profit_margin,
            'average_profit': average_profit,
            'average_selling_price_with_discount': average_selling_price_with_discount,
            'top_performing_products': list(top_performing_products),
            'low_performing_products': list(low_performing_products),
            'sales_by_product': list(sales_by_product),
            'profit_by_product': list(profit_by_product)
        }
        serializer = ProductPerformanceReportSerializer(data)
        return Response(serializer.data)

    @action(detail=False, methods=['get'], url_path='online-preorder-analytics')
    def online_preorder_analytics(self, request):
        """Get analytics for online preorders including top products and categories"""
        date_from, date_to, error = self._get_date_range(request)
        if error:
            return error

        # Get online preorders in date range
        online_preorders = OnlinePreorder.objects.filter(created_at__range=[date_from, date_to])
        
        # Total stats
        total_orders = online_preorders.count()
        completed_orders = online_preorders.filter(status='COMPLETED')
        total_sales_count = completed_orders.count()
        total_revenue = completed_orders.aggregate(total=Sum('total_amount'))['total'] or Decimal('0.00')
        total_profit = completed_orders.aggregate(total=Sum('profit'))['total'] or Decimal('0.00')
        average_order_value = total_revenue / total_sales_count if total_sales_count > 0 else Decimal('0.00')

        # Get sales from Sale model with sale_type='online_preorder' for more accurate analytics
        online_sales = Sale.objects.filter(
            date__range=[date_from, date_to],
            status='completed',
            sale_type='online_preorder'
        )
        
        # Top products from online preorder sales
        top_products_qs = SaleItem.objects.filter(
            sale__in=online_sales
        ).values(
            'product__id',
            'product__name',
            'product__category__name'
        ).annotate(
            product_id=F('product__id'),
            product_name=F('product__name'),
            category_name=F('product__category__name'),
            total_sales=Sum('total'),
            quantity_sold=Sum('quantity'),
            total_profit=Sum('profit')
        ).order_by('-total_sales')[:10]

        # Top categories from online preorder sales
        top_categories_qs = SaleItem.objects.filter(
            sale__in=online_sales
        ).values(
            'product__category__name'
        ).annotate(
            category_name=F('product__category__name'),
            total_sales=Sum('total'),
            quantity_sold=Sum('quantity'),
            total_profit=Sum('profit'),
            order_count=Count('sale', distinct=True)
        ).order_by('-total_sales')[:10]

        # Sales by date - convert dates to strings
        sales_by_date = online_sales.annotate(
            sale_date=Cast('date', DateField())
        ).values('sale_date').annotate(
            total=Sum('total'),
            orders_count=Count('id')
        ).order_by('sale_date')
        
        # Convert dates to strings for JSON serialization
        sales_by_date_list = []
        for item in sales_by_date:
            date_str = str(item['sale_date']) if item['sale_date'] else None
            sales_by_date_list.append({
                'date': date_str,
                'total': str(item['total']),
                'orders_count': item['orders_count']
            })

        # Convert QuerySets to lists first
        top_products_list = list(top_products_qs)
        top_categories_list = list(top_categories_qs)
        
        # If no sales exist, try to get data from OnlinePreorder items directly
        if len(top_products_list) == 0 and completed_orders.exists():
            # Extract product data from OnlinePreorder items JSON
            from collections import defaultdict
            product_stats = defaultdict(lambda: {'quantity': 0, 'total': Decimal('0.00'), 'profit': Decimal('0.00'), 'name': '', 'category': ''})
            
            for order in completed_orders:
                if order.items:
                    for item in order.items:
                        product_id = item.get('product_id')
                        if product_id:
                            try:
                                product = Product.objects.get(id=product_id)
                                qty = int(item.get('quantity', 0))
                                unit_price = Decimal(str(item.get('unit_price', 0)))
                                discount = Decimal(str(item.get('discount', 0) or 0))
                                total = (unit_price * qty) - discount
                                cost = Decimal(str(product.cost_price)) * qty
                                profit = total - cost
                                
                                product_stats[product_id]['quantity'] += qty
                                product_stats[product_id]['total'] += total
                                product_stats[product_id]['profit'] += profit
                                product_stats[product_id]['name'] = product.name
                                product_stats[product_id]['category'] = product.category.name if product.category else 'Uncategorized'
                            except Product.DoesNotExist:
                                pass
            
            # Convert to list format
            top_products_list = []
            for product_id, stats in sorted(product_stats.items(), key=lambda x: x[1]['total'], reverse=True)[:10]:
                top_products_list.append({
                    'product_id': product_id,
                    'product_name': stats['name'],
                    'category_name': stats['category'],
                    'total_sales': str(stats['total']),
                    'quantity_sold': stats['quantity'],
                    'total_profit': str(stats['profit'])
                })
        
        # Get top categories from products if no sales
        if len(top_categories_list) == 0 and completed_orders.exists():
            from collections import defaultdict
            category_stats = defaultdict(lambda: {'quantity': 0, 'total': Decimal('0.00'), 'profit': Decimal('0.00'), 'orders': set()})
            
            for order in completed_orders:
                if order.items:
                    for item in order.items:
                        product_id = item.get('product_id')
                        if product_id:
                            try:
                                product = Product.objects.get(id=product_id)
                                category_name = product.category.name if product.category else 'Uncategorized'
                                qty = int(item.get('quantity', 0))
                                unit_price = Decimal(str(item.get('unit_price', 0)))
                                discount = Decimal(str(item.get('discount', 0) or 0))
                                total = (unit_price * qty) - discount
                                cost = Decimal(str(product.cost_price)) * qty
                                profit = total - cost
                                
                                category_stats[category_name]['quantity'] += qty
                                category_stats[category_name]['total'] += total
                                category_stats[category_name]['profit'] += profit
                                category_stats[category_name]['orders'].add(order.id)
                            except Product.DoesNotExist:
                                pass
            
            # Convert to list format
            top_categories_list = []
            for category_name, stats in sorted(category_stats.items(), key=lambda x: x[1]['total'], reverse=True)[:10]:
                top_categories_list.append({
                    'category_name': category_name,
                    'total_sales': str(stats['total']),
                    'quantity_sold': stats['quantity'],
                    'total_profit': str(stats['profit']),
                    'order_count': len(stats['orders'])
                })

        # Status breakdown
        status_breakdown = {}
        for status_choice in OnlinePreorder.STATUS_CHOICES:
            status_breakdown[status_choice[0]] = online_preorders.filter(status=status_choice[0]).count()

        # Convert QuerySets to lists and handle None values
        top_products_final = []
        for item in top_products_list:
            top_products_final.append({
                'product_id': item.get('product_id') or 0,
                'product_name': item.get('product_name') or 'Unknown',
                'category_name': item.get('category_name') or 'Uncategorized',
                'total_sales': str(item.get('total_sales', '0.00')),
                'quantity_sold': item.get('quantity_sold', 0),
                'total_profit': str(item.get('total_profit', '0.00'))
            })
        
        top_categories_final = []
        for item in top_categories_list:
            top_categories_final.append({
                'category_name': item.get('category_name') or 'Uncategorized',
                'total_sales': str(item.get('total_sales', '0.00')),
                'quantity_sold': item.get('quantity_sold', 0),
                'total_profit': str(item.get('total_profit', '0.00')),
                'order_count': item.get('order_count', 0)
            })

        data = {
            'total_orders': total_orders,
            'total_sales_count': total_sales_count,
            'total_revenue': str(total_revenue),
            'total_profit': str(total_profit),
            'average_order_value': str(average_order_value),
            'top_products': top_products_final,
            'top_categories': top_categories_final,
            'sales_by_date': sales_by_date_list,
            'status_breakdown': status_breakdown,
        }

        return Response(data)

class SavedReportViewSet(viewsets.ModelViewSet):
    queryset = SavedReport.objects.all()
    serializer_class = SavedReportSerializer

    def perform_create(self, serializer):
        report = Report.objects.get(id=serializer.validated_data['report_id'])
        report.is_saved = True
        report.save()
        serializer.save(report=report) 